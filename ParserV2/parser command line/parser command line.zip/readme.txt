Finds and prints omissions of data to command line.

usage:
$ python findomissions.py -h <help> -q <question> 

json file must be in the same directory as the python file

questions (case insensitive):
 -- sibdq
 -- psqi
 -- vas (pertains to global vas)
 -- sleep



** later additions wong baker

output:


** applies to psqi/sibdq
Dates completed during predicted window
Dates completed outside predicted window
Dates did not complete within window and no answers available

**
dates completed for others may not have any correlation to within/outside window
additional feature must be added

**
note of which patients must be contacted after output


